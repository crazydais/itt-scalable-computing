#ifndef CUDA_LAB1_H
#define	CUDA_LAB1_H



//Define the kernel prototype
__global__ void SimpleKernel(int *);


#endif